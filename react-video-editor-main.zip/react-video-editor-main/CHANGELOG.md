# remotion-captions

## 0.0.72

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@3.1.1
  - @designcombo/state@3.1.1
  - @designcombo/types@3.1.1

## 0.0.71

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@4.0.0
  - @designcombo/state@4.0.0
  - @designcombo/types@3.1.0

## 0.0.70

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@3.0.4
  - @designcombo/state@3.0.4
  - @designcombo/types@3.0.4

## 0.0.69

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@3.0.3
  - @designcombo/state@3.0.3
  - @designcombo/types@3.0.3

## 0.0.68

### Patch Changes

- Updated dependencies
  - @designcombo/state@3.0.2
  - @designcombo/timeline@3.0.2
  - @designcombo/types@3.0.2

## 0.0.67

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@3.0.2
  - @designcombo/state@3.0.2
  - @designcombo/types@3.0.2

## 0.0.66

### Patch Changes

- Updated dependencies
  - @designcombo/state@3.0.0
  - @designcombo/timeline@3.0.0
  - @designcombo/types@2.2.0

## 0.0.65

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@3.0.0
  - @designcombo/state@3.0.0
  - @designcombo/types@2.1.0

## 0.0.64

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@2.0.7
  - @designcombo/state@2.0.7
  - @designcombo/types@2.0.7

## 0.0.63

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@2.0.6
  - @designcombo/state@2.0.6
  - @designcombo/types@2.0.6

## 0.0.62

### Patch Changes

- Updated dependencies
  - @designcombo/state@2.0.6
  - @designcombo/timeline@2.0.6
  - @designcombo/types@2.0.6

## 0.0.61

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@2.0.5
  - @designcombo/state@2.0.5
  - @designcombo/types@2.0.5

## 0.0.60

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@2.0.4
  - @designcombo/state@2.0.4
  - @designcombo/types@2.0.4

## 0.0.59

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@2.0.3
  - @designcombo/state@2.0.3
  - @designcombo/types@2.0.3

## 0.0.58

### Patch Changes

- Updated dependencies [05070b6]
- Updated dependencies
  - @designcombo/timeline@2.0.2
  - @designcombo/state@2.0.2
  - @designcombo/types@2.0.2

## 0.0.57

### Patch Changes

- Updated dependencies
- Updated dependencies
  - @designcombo/timeline@2.0.1
  - @designcombo/state@2.0.1
  - @designcombo/types@2.0.1

## 0.0.56

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@2.0.0
  - @designcombo/state@2.0.0
  - @designcombo/types@1.1.0

## 0.0.55

### Patch Changes

- Updated dependencies
  - @designcombo/state@1.0.8
  - @designcombo/timeline@1.0.8
  - @designcombo/types@1.0.8

## 0.0.54

### Patch Changes

- Updated dependencies
  - @designcombo/state@1.0.7
  - @designcombo/timeline@1.0.7
  - @designcombo/types@1.0.7

## 0.0.53

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.6
  - @designcombo/state@1.0.6
  - @designcombo/types@1.0.6

## 0.0.52

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.5
  - @designcombo/state@1.0.5
  - @designcombo/types@1.0.5

## 0.0.51

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.4
  - @designcombo/state@1.0.4
  - @designcombo/types@1.0.4

## 0.0.50

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.3
  - @designcombo/state@1.0.3
  - @designcombo/types@1.0.3

## 0.0.49

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.2
  - @designcombo/events@1.0.2
  - @designcombo/state@1.0.2
  - @designcombo/types@1.0.2

## 0.0.48

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.1
  - @designcombo/events@0.2.1
  - @designcombo/state@1.0.1
  - @designcombo/types@0.2.1

## 0.0.47

### Patch Changes

- Updated dependencies
  - @designcombo/transitions@0.11.0
  - @designcombo/timeline@1.0.0
  - @designcombo/events@0.2.0
  - @designcombo/state@1.0.0
  - @designcombo/types@0.2.0

## 0.0.46

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.45
  - @designcombo/events@0.1.45
  - @designcombo/state@0.1.45
  - @designcombo/types@0.1.45

## 0.0.45

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.44
  - @designcombo/events@0.1.44
  - @designcombo/state@0.1.44
  - @designcombo/types@0.1.44

## 0.0.44

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.43
  - @designcombo/events@0.1.43
  - @designcombo/state@0.1.43
  - @designcombo/types@0.1.43

## 0.0.43

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.42
  - @designcombo/events@0.1.42
  - @designcombo/state@0.1.42
  - @designcombo/types@0.1.42

## 0.0.42

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.41
  - @designcombo/state@0.1.41
  - @designcombo/timeline@0.1.41
  - @designcombo/types@0.1.41

## 0.0.41

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.40
  - @designcombo/events@0.1.40
  - @designcombo/state@0.1.40
  - @designcombo/types@0.1.40

## 0.0.40

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.39
  - @designcombo/state@0.1.39
  - @designcombo/timeline@0.1.39
  - @designcombo/types@0.1.39

## 0.0.39

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.38
  - @designcombo/events@0.1.38
  - @designcombo/state@0.1.38
  - @designcombo/types@0.1.38

## 0.0.38

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.37
  - @designcombo/events@0.1.37
  - @designcombo/state@0.1.37
  - @designcombo/types@0.1.37

## 0.0.37

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.36
  - @designcombo/events@0.1.36
  - @designcombo/state@0.1.36
  - @designcombo/types@0.1.36

## 0.0.36

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.35
  - @designcombo/events@0.1.35
  - @designcombo/state@0.1.35
  - @designcombo/types@0.1.35

## 0.0.35

### Patch Changes

- Updated dependencies
  - @designcombo/transitions@0.10.4
  - @designcombo/timeline@0.1.34
  - @designcombo/events@0.1.34
  - @designcombo/state@0.1.34
  - @designcombo/types@0.1.34

## 0.0.34

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.33
  - @designcombo/events@0.1.33
  - @designcombo/state@0.1.33
  - @designcombo/types@0.1.33

## 0.0.33

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.32
  - @designcombo/events@0.1.32
  - @designcombo/state@0.1.32
  - @designcombo/types@0.1.32

## 0.0.32

### Patch Changes

- Updated dependencies
  - @designcombo/transitions@0.10.3

## 0.0.31

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.31
  - @designcombo/events@0.1.31
  - @designcombo/state@0.1.31
  - @designcombo/types@0.1.31

## 0.0.30

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.28
  - @designcombo/events@0.1.28
  - @designcombo/state@0.1.28
  - @designcombo/types@0.1.28

## 0.0.29

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.29
  - @designcombo/events@0.1.29
  - @designcombo/state@0.1.29
  - @designcombo/types@0.1.29

## 0.0.28

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.28
  - @designcombo/events@0.1.28
  - @designcombo/state@0.1.28
  - @designcombo/types@0.1.28

## 0.0.27

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.27
  - @designcombo/events@0.1.27
  - @designcombo/state@0.1.27
  - @designcombo/types@0.1.27

## 0.0.26

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.26
  - @designcombo/events@0.1.26
  - @designcombo/state@0.1.26
  - @designcombo/types@0.1.26

## 0.0.25

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.25
  - @designcombo/events@0.1.25
  - @designcombo/state@0.1.25
  - @designcombo/types@0.1.25

## 0.0.24

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.24
  - @designcombo/events@0.1.24
  - @designcombo/types@0.1.24
  - @designcombo/state@0.1.24

## 0.0.23

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.23
  - @designcombo/events@0.1.23
  - @designcombo/state@0.1.24
  - @designcombo/types@0.1.23

## 0.0.22

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.23
  - @designcombo/events@0.1.23
  - @designcombo/state@0.1.23
  - @designcombo/types@0.1.23

## 0.0.21

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.22
  - @designcombo/state@0.1.22
  - @designcombo/timeline@0.1.22
  - @designcombo/types@0.1.22

## 0.0.20

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.21
  - @designcombo/events@0.1.21
  - @designcombo/state@0.1.21
  - @designcombo/types@0.1.21

## 0.0.19

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.20
  - @designcombo/events@0.1.20
  - @designcombo/state@0.1.20
  - @designcombo/types@0.1.20

## 0.0.18

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.19
  - @designcombo/state@0.1.19
  - @designcombo/timeline@0.1.19
  - @designcombo/types@0.1.19

## 0.0.17

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.18
  - @designcombo/state@0.1.18
  - @designcombo/timeline@0.1.18
  - @designcombo/types@0.1.18

## 0.0.16

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.17
  - @designcombo/events@0.1.17
  - @designcombo/state@0.1.17
  - @designcombo/types@0.1.17

## 0.0.15

### Patch Changes

- Updated dependencies
  - @designcombo/types@0.1.16
  - @designcombo/events@0.1.16
  - @designcombo/state@0.1.16
  - @designcombo/timeline@0.1.16

## 0.0.14

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.15
  - @designcombo/events@0.1.15
  - @designcombo/state@0.1.15
  - @designcombo/types@0.1.15

## 0.0.13

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.14
  - @designcombo/state@0.1.14
  - @designcombo/timeline@0.1.14
  - @designcombo/types@0.1.14

## 0.0.12

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.13
  - @designcombo/events@0.1.13
  - @designcombo/state@0.1.13
  - @designcombo/types@0.1.13

## 0.0.11

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.12
  - @designcombo/events@0.1.12
  - @designcombo/state@0.1.12
  - @designcombo/types@0.1.12

## 0.0.10

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.11
  - @designcombo/state@0.1.11
  - @designcombo/timeline@0.1.11
  - @designcombo/types@0.1.11

## 0.0.9

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.10
  - @designcombo/events@0.1.10
  - @designcombo/state@0.1.10
  - @designcombo/types@0.1.10

## 0.0.8

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.9
  - @designcombo/events@0.1.9
  - @designcombo/state@0.1.9
  - @designcombo/types@0.1.9

## 0.0.7

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.7
  - @designcombo/state@0.1.7
  - @designcombo/timeline@0.1.7
  - @designcombo/types@0.1.7

## 0.0.6

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.6
  - @designcombo/state@0.1.6
  - @designcombo/timeline@0.1.6
  - @designcombo/types@0.1.6

## 0.0.5

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@0.1.5
  - @designcombo/events@0.1.5
  - @designcombo/state@0.1.5
  - @designcombo/types@0.1.5

## 0.0.4

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.0
  - @designcombo/events@0.2.0
  - @designcombo/state@1.0.0
  - @designcombo/types@0.2.0

## 0.0.3

### Patch Changes

- Updated dependencies
  - @designcombo/timeline@1.0.0
  - @designcombo/events@0.2.0
  - @designcombo/state@1.0.0
  - @designcombo/types@0.2.0

## 0.0.2

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.4
  - @designcombo/state@0.1.4
  - @designcombo/timeline@0.1.4
  - @designcombo/types@0.1.4

## 0.0.1

### Patch Changes

- Updated dependencies
  - @designcombo/events@0.1.3
  - @designcombo/state@0.1.3
  - @designcombo/timeline@0.1.3
  - @designcombo/types@0.1.3
