export const Elements = () => {
  return (
    <div className="flex-1">
      <div className="text-md text-text-primary flex h-12 items-center px-4 font-medium">
        Shapes
      </div>
    </div>
  );
};
