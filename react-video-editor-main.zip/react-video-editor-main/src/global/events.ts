export const PLAYER_PREFIX = "player";
export const PLAYER_PLAY = `${PLAYER_PREFIX}:play`;
export const PLAYER_PAUSE = `${PLAYER_PREFIX}:pause`;
export const PLAYER_SEEK = `${PLAYER_PREFIX}:seek`;
export const PLAYER_SEEK_TO = `${PLAYER_PREFIX}:seekTo`;
export const PLAYER_SEEK_BY = `${PLAYER_PREFIX}:seekBy`;
export const PLAYER_TOGGLE_PLAY = `${PLAYER_PREFIX}:togglePlay`;

const TIMELINE_PREFIX = "timeline";
export const TIMELINE_ITEM_DURATION_CHANGED = `${TIMELINE_PREFIX}:durationChanged`;
